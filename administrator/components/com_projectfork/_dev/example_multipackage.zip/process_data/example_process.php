<?php
/*
* This is the entry file for your process and may contain all your code.
*/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );

/*
* The PFload class can be utilized to easily include process related css/js files
*/
$load = PFload::GetInstance();

/*
* This is how you can load a css file from your process
* The second param must be the name of your process (or any other)
*/
$load->ProcessCSS('example.css', 'example_process');

/*
* Same thing for JS files
*/
$load->ProcessJS('example.js', 'example_process');

/*
* This is how you can retrieve config settings for your process.
* The first argument must be the name of the config setting (see your process xml file)
* The second parameter must be the name of your process
*/
$cfg = PFconfig::GetInstance();
$setting = $cfg->Get('my_setting', 'example_process');


/*
* You can also retrieve system settings, such as "hide joomla template"
*/
$hide = $cfg->Get('hide_template', 'system');

/*
* Every process receives an array ($data) with certain parameters.
* Note that the array may be empty, depending on the process event (like in this example)
* To know which arguments are passed, you'll have to lookup the specific event in the code (usually in the section *.class.php files)
*/
$args = $data;
?>