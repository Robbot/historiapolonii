<?php
/*
* This is the entry file for your panel and may contain all your code html.
* If the panel produces no output, the panel won't be shown at all (including the html code that wraps it)
*/

// This line must be at the top of every PHP file to prevent direct access!
defined( '_JEXEC' ) or die( 'Restricted access' );

/*
* The PFload class can be utilized to easily include panel related css/js and images
*/
$load = PFload::GetInstance();

/*
* This is how you can load a css file from your panel
* The second param must be the name of your panel (or any other)
*/
$load->PanelCSS('example.css', 'example_panel');

/*
* Same thing for JS files
*/
$load->PanelJS('example.js', 'example_panel');

/*
* And images
*/
echo $load->PanelImg('projectfork.png', 'example_panel');

/*
* This is how you can retrieve config settings for your panel.
* The first argument must be the name of the config setting (see your panel xml file)
* The second parameter must be the name of your panel
*/
$cfg = PFconfig::GetInstance();
$setting = $cfg->Get('my_setting', 'example_panel');


/*
* You can also retrieve system settings, such as "hide joomla template"
*/
$hide = $cfg->Get('hide_template', 'system');
?>