<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

echo 'This page has been modded! Disable or uninstall the mod "Example Mod" by going to: Projectfork -> Config -> Mods';
?>